<?php
include 'conexion.php';

$query = "ALTER TABLE formulario";
$resultado = mysqli_query($conectar, $query);


$nombre_completo = $_POST['nombre_completo'];
$documento_identidad = $_POST['documento_identidad'];
$numero_contacto = $_POST['numero_contacto'];
$info_vehiculo = $_POST['info_vehiculo'];
$placa = $_POST['placa'];
$tipo_vehiculo = $_POST['tipo_vehiculo'];
$hora_entrada = $_POST['hora_entrada'];


$sql = "INSERT INTO personalizado (nombre_completo, documento_identidad, numero_contacto, info_vehiculo, placa, tipo_vehiculo, hora_entrada ) 
VALUES ('$nombre_completo','$documento_identidad','$numero_contacto','$info_vehiculo','$placa','$tipo_vehiculo','$hora_entrada')";
$resultado = mysqli_query($conectar, $sql);

if ($resultado) {
    echo "registro ok";
}else{
    echo "Error al registrar";
}