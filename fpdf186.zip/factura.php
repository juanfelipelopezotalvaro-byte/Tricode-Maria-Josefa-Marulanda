<?php
session_start();
require('fpdf186/fpdf.php');

if (!isset($_SESSION['factura'])) {
    die("No hay datos para generar la factura.");
}

$factura = $_SESSION['factura'];

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);

$pdf->Cell(0,10,"Factura Parqueadero",0,1,'C');
$pdf->Ln(10);

$pdf->SetFont('Arial','',12);
$pdf->Cell(0,10,"Cliente: ".$factura['nombre'],0,1);
$pdf->Cell(0,10,"Documento: ".$factura['documento'],0,1);
$pdf->Cell(0,10,"Telefono: ".$factura['telefono'],0,1);
$pdf->Cell(0,10,"Vehiculo: ".$factura['info'],0,1);
$pdf->Cell(0,10,"Placa: ".$factura['placa'],0,1);
$pdf->Cell(0,10,"Tipo: ".$factura['tipo'],0,1);
$pdf->Cell(0,10,"Hora Entrada: ".$factura['hora_entrada'],0,1);
$pdf->Cell(0,10,"Hora Salida: ".$factura['hora_salida'],0,1);
$pdf->Cell(0,10,"Tiempo Total: ".$factura['tiempo_total']." hora(s)",0,1);
$pdf->Cell(0,10,"Valor a Pagar: $".$factura['valor'],0,1);

$pdf->Output();
?>