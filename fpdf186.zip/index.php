<?php
include("conexion.php");
date_default_timezone_set("America/Bogota");
$hora = date("Y-m-d H:i:s");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_completo'];
    $documento = $_POST['documento_identidad'];
    $contacto = $_POST['numero_contacto'];
    $info = $_POST['info_vehiculo'];
    $placa = $_POST['placa'];
    $tipo = $_POST['tipo_vehiculo'];
    $entrada = $_POST['hora_entrada'];

    $sql = "INSERT INTO formulario 
            (nombre_completo, documento_identidad, numero_contacto, info_vehiculo, placa, tipo_vehiculo, hora_entrada) 
            VALUES ('$nombre','$documento','$contacto','$info','$placa','$tipo','$entrada')";

    if ($conectar->query($sql) === TRUE) {
        echo "<div class='alert success'><i class='fas fa-check-circle'></i> Vehículo registrado con éxito ✅</div>";
    } else {
        echo "<div class='alert error'><i class='fas fa-exclamation-triangle'></i> Error: " . $conectar->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro Parqueadero</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="card">
        <h2><i class="fas fa-parking"></i> Registro de Vehículos</h2>

        <form method="post">
            <label><i class="fas fa-user"></i> Nombre completo:</label>
            <input type="text" name="nombre_completo" required>

            <label><i class="fas fa-id-card"></i> Documento de identidad:</label>
            <input type="text" name="documento_identidad" required>

            <label><i class="fas fa-phone"></i> Número de contacto:</label>
            <input type="text" name="numero_contacto" required>

            <label><i class="fas fa-car-side"></i> Información del vehículo:</label>
            <input type="text" name="info_vehiculo" placeholder="Marca, modelo, color" required>

            <label><i class="fas fa-key"></i> Placa:</label>
            <input type="text" name="placa" required>

            <label><i class="fas fa-motorcycle"></i> Tipo de vehículo:</label>
            <select name="tipo_vehiculo" required>
                <option value="Carro">Carro</option>
                <option value="Moto">Moto</option>
                <option value="Bicicleta">Bicicleta</option>
            </select>

            <label><i class="fas fa-clock"></i> Hora de entrada:</label>
            <input type="text" name="hora_entrada" value="<?php echo $hora; ?>" readonly>

            <button type="submit"><i class="fas fa-save"></i> Registrar</button>
        </form>

        <a class="btn-link" href="salida.php"><i class="fas fa-sign-out-alt"></i> Procesar Salida</a>
    </div>
</body>
</html>