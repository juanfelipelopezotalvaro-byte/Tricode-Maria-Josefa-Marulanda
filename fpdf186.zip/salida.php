<?php
session_start();
include("conexion.php");
date_default_timezone_set("America/Bogota");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $placa = $_POST['placa'];
    $hora_salida = date("Y-m-d H:i:s");

    $sql = "SELECT * FROM formulario WHERE placa='$placa' ORDER BY id DESC LIMIT 1";
    $resultado = $conectar->query($sql);

    if ($resultado->num_rows > 0) {
        $vehiculo = $resultado->fetch_assoc();

        $hora_entrada = strtotime($vehiculo['hora_entrada']);
        $hora_salida_ts = strtotime($hora_salida);
        $tiempo_total = ($hora_salida_ts - $hora_entrada) / 3600;

        $tarifa = 3000;
        $costo = ceil($tiempo_total) * $tarifa;

        // ✅ Guardar en la sesión para factura.php
        $_SESSION['factura'] = [
            'nombre'       => $vehiculo['nombre_completo'],
            'documento'    => $vehiculo['documento_identidad'],
            'telefono'     => $vehiculo['numero_contacto'],
            'info'         => $vehiculo['tipo_vehiculo'],
            'placa'        => $vehiculo['placa'],
            'tipo'         => $vehiculo['tipo_vehiculo'],
            'hora_entrada' => $vehiculo['hora_entrada'],
            'hora_salida'  => $hora_salida,
            'tiempo_total' => ceil($tiempo_total),
            'valor'        => $costo
        ];

        // Ahora sí redirigir a la factura
        header("Location: factura.php");
        exit;
    } else {
        $mensaje = "No se encontró un vehículo con esa placa.";
}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Salida de Vehículo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="salida-body">
    <div class="salida-card">
        <h2 class="salida-title"><i class="fa-solid fa-door-open"></i> Registrar Salida</h2>

        <form method="post" action="" class="salida-form">
            <div class="salida-group">
                <label class="salida-label"><i class="fa-solid fa-key"></i> Placa:</label>
                <input type="text" name="placa" class="salida-input" required placeholder="Ej: ABC123">
            </div>

            <button type="submit" class="salida-btn salida-btn-pdf">
                <i class="fa-solid fa-file-invoice-dollar"></i> Generar Factura
            </button>
        </form>

       
          
      

        <a href="index.php" class="salida-btn salida-btn-back"><i class="fa-solid fa-arrow-left"></i> Volver</a>
    </div>
</body>
</html>