<?php
// config.php
// Opcional: activar errores en desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$host= "localhost";
$user= "root";
$pass= "";
$bd= "reto";

$conectar=mysqli_connect($host, $user, $pass, $bd);



?>