-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-10-2025 a las 20:32:34
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `reto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulario`
--

CREATE TABLE `formulario` (
  `id` int(11) NOT NULL,
  `nombre_completo` varchar(100) DEFAULT NULL,
  `documento_identidad` varchar(100) DEFAULT NULL,
  `numero_contacto` varchar(20) DEFAULT NULL,
  `info_vehiculo` varchar(500) DEFAULT NULL,
  `placa` varchar(20) DEFAULT NULL,
  `tipo_vehiculo` varchar(50) DEFAULT NULL,
  `hora_entrada` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `formulario`
--

INSERT INTO `formulario` (`id`, `nombre_completo`, `documento_identidad`, `numero_contacto`, `info_vehiculo`, `placa`, `tipo_vehiculo`, `hora_entrada`) VALUES
(11, 'Emanuel Carmona Tobon', '1040876452', '3001241525', 'renault, camioneta, rojo', 'HYD145', 'Carro', '2025-10-02'),
(12, 'Ever yamid vargas', '1040031113', '3001241526', 'Hilux, 1996, blanca', 'TVL897', 'Carro', '2025-10-02'),
(13, 'Ever yamid vargas', '1040031113', '3001241526', 'Hilux, 1996, blanca', 'TVL897', 'Carro', '2025-10-02'),
(14, 'Emanuel Carmona Tobon', '1040876452', '3001241525', 'Hilux, 1996, blanca', 'MNR849', 'Carro', '2025-10-02'),
(15, 'Emanuel Carmona Tobon', '1040876452', '3001241525', 'Hilux, 1996, blanca', 'MNR849', 'Carro', '2025-10-02'),
(16, 'Vladimir giraldo', '71114764', '3206862282', 'Mazda, 2003, gris', 'EWZ581', 'Carro', '2025-10-02'),
(17, 'juan', '1040876452', '3001241525', 'Hilux, 1996, blanca', 'MNR840', 'Carro', '2025-10-02'),
(18, 'juan', '1040876452', '3001241525', 'Hilux, 1996, blanca', 'MNR849', 'Carro', '2025-10-02'),
(19, 'Emanuel Carmona Tobon', '1040876452', '3001241525', 'Hilux, 1996, blanca', 'MNR849', 'Carro', '2025-10-02');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `formulario`
--
ALTER TABLE `formulario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `formulario`
--
ALTER TABLE `formulario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
